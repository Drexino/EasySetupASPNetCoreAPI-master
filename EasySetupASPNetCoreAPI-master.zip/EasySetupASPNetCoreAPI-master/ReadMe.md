# EasySetupAspNetCoreAPI

EasySetupAspNetCoreAPI is a basic start up project for asp.net core web API with the following already implemented:
1. User Registration.
2. User Authentication (JWT authentication).
3. Swagger documentation.
This project helps you to kick start web API project without worrying about setting up user authentication and authorizations.

## Prerequisite

Asp.net core 2.2 or later

